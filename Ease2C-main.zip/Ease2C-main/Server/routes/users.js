import express from 'express';
import { verifyToken } from '../middleware/auth.js';
import { getUser, getUserDocument, } from '../controllers/users.js';

const router = express.Router();

/* READ */
router.get('/:id', verifyToken, getUser );
router.get('/:id/documents', verifyToken, getUserDocument );

/* UPDATE */

export default router;