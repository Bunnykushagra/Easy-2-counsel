import React from 'react'

const ThemeDialog = () => {
  return (
    <div>ThemeDialog</div>
  )
}

export default ThemeDialog