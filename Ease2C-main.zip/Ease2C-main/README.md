# Ease2C
This is the web app which ensures the automation  of the counselling process of new-enrolled college students.
